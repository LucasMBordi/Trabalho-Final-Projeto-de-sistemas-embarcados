var indexSectionsWithContent =
{
  0: "cgmrst",
  1: "cgmrst"
};

var indexSectionNames =
{
  0: "all",
  1: "files"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos"
};

