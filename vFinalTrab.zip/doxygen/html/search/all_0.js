var searchData=
[
  ['client_2ec_0',['client.c',['../client_8c.html',1,'']]]
];
