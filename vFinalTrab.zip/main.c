#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <string.h>

#include "server.h"



int main(int argc, char **argv){
    pthread_t t2;
    serverParam servidor, *servidor1;
    sigset_t alarm_sig;
    long procs;
	int i, rc;

    procs = sysconf(_SC_NPROCESSORS_ONLN);
    CPU_ZERO(&s);
    CPU_SET(0, &s);
    param.sched_priority = prio_max;    

    sigemptyset (&alarm_sig);
	for (i = SIGRTMIN; i <= SIGRTMAX; i++)
	    sigaddset (&alarm_sig, i);
	sigprocmask (SIG_BLOCK, &alarm_sig, NULL);

    servidor.argc = argc;
    servidor.argv = argv;

    servidor1 = &servidor;
    
    //cria a thread do servidor
    rc = pthread_create(&t2, NULL, server, (void*)servidor1);
    pthread_setaffinity_np(t2, sizeof(s), &s);
    pthread_setschedparam(t2, SCHED_RR, &param);
    if(rc){
        printf("Erro criando a thread servidor!\n");
        return 0;
    }else{
        printf("Thread servidor criada!\n");
    }

    pthread_join(t2, NULL);



    return 0;
}
