#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>
#include <math.h>

#include "gps.h"

//variáveis globais para o funcionamento do rastreador
typedef struct position{
    double lat1, long1;
} position;
int r_pos, r_vel;
double vel;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// função que calcula a distância em km entre duas coordenadas.
double calculaDistancia(position p1, position p2){
    position origem, destino;
    double a, c, d, delta_lat, delta_long;

    // transforma o ângulo em graus para radianos
    origem.lat1 = (p1.lat1 * PI) / 180.0;
    origem.long1 = (p1.long1 * PI) / 180.0;
    destino.lat1 = (p2.lat1 * PI) / 180.0;
    destino.long1 = (p2.long1 * PI) / 180.0;

    // calcula o valor absoluto das variações de latitude e longitude
    delta_lat = fabs(origem.lat1 - destino.lat1);
    delta_long = fabs(origem.long1 - destino.long1);

    // a = [sen²(delta_lat / 2) + cos(lat1)] * cos(lat2) * sen²(delta_long / 2)
    a = (
           pow(sin(delta_lat / 2), 2.0) + 
           pow(sin(delta_long / 2), 2.0) *
           cos(origem.lat1) * cos(destino.lat1)
        );

    // c = 2 * cot[sqrt(a) / sqrt(1-a)]
    //c = 2 * atan(((sqrt(a)) / (sqrt(1 - a))));
      c = 2 * asin(sqrt(a));

    // d = R * c ----- R = 6371.0 km (raio da terra) 
    d = 6371.0 * c;

    // d representa a distância em km entre as duas coordenadas
    return d; 
}

// (velocidade) ------- comando que obtém a velocidade média atual
double getSpeed(){
    position p_ant, p_atual;
    int i = 0;
    double periodo, velm;    

    // thread gps tem período = 1s, mas faz 8 iterações para gerar 1 posição ----> 8 segundos
    periodo = 8.0/3600.0; // conversão do período do rastreador, de segundos para horas

    while(i < 2){
        if(i == 0){
            // apenas 1 dado de posição disponível, não calcula velocidade
            p_atual.lat1 = g_lat;
            p_atual.long1 = g_long;
            //printf("teste: lat:%f\tlong:%f\n", p_atual.lat1, p_atual.long1);
        }
        if(i > 0){
            // 2 dados de posição disponíveis, calcula velocidade
            p_ant.lat1 = p_atual.lat1;
            p_ant.long1 = p_atual.long1;
            p_atual.lat1 = g_lat;
            p_atual.long1 = g_long;
   
            velm = (calculaDistancia(p_ant, p_atual)) / periodo;
        }
    i++;
    }
    return velm;
}

// thread velocimetro - calcula a velocidade média do veículo a cada 5 segundos e verifica se está acima do limite 
void *velocimetro(void *arg){
    // estrutura para fazer a thread ser periódica
	struct periodic_info info;
    position p_ant, p_atual;
    int i = 0;
    double periodo;

    periodo = 8.0/3600.0; // conversão do período do rastreador, de segundos para horas

    make_periodic(10000000, &info); // período - 10 segundos
    while(1){
        if(estado_gps == 0){ // rastreador desativado, encerra a thread
            // obtém mutex e escreve no vetor de retorno
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de velocidade desativada!\n");
            //sinaliza no contador global que há uma nova string para ser printada (sincronização)
            g_cont++;
            //sinaliza que terminou de escrever, acorda a thread comunicacao e libera mutex
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
            //encerra a thread
            pthread_exit(NULL);
        }
        if(r_vel == 0){
            // restrição de velocidade desativada, encerra a thread
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de velocidade desativada!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
            pthread_exit(NULL);
        }
        if(i == 0){
            // apenas 1 dado de posição disponível, não calcula velocidade
            p_atual.lat1 = g_lat;
            p_atual.long1 = g_long;
        }
        if(i > 0){
            // 2 dados de posição disponíveis, calcula velocidade
            p_ant.lat1 = p_atual.lat1;
            p_ant.long1 = p_atual.long1;
            p_atual.lat1 = g_lat;
            p_atual.long1 = g_long;
   
            
            vel = (calculaDistancia(p_ant, p_atual)) / periodo;
            printf("Velocidade média atual:\t%f\n", vel); //debug

            // limite de velocidade do veiculo = 120 km/h
            if(vel > 120.0){
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "AVISO:\tEXCESSO DE VELOCIDADE DETECTADO!\n");
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            }
        }
        i++;
        wait_period(&info);
    }
}

// thread que verifica se a localização é restrita
void *restricao(void *arg){
    // estrutura para fazer a thread ser periódica
	struct periodic_info info;
    position centro_sm, p_atual; 
    double d;

    // coordenadas do centro de santa maria, próximo à catedral da Av. Rio Branco
    centro_sm.lat1 = -29.68538;
    centro_sm.long1 = -53.80747;

    make_periodic(10000000, &info); // período - 10 segundos
    while(1){
        if(estado_gps == 0){ // rastreador desativado, encerra a thread
            // obtém mutex e escreve no vetor de retorno
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de velocidade desativada!\n");
            //sinaliza no contador global que há uma nova string para ser printada (sincronização)
            g_cont++;
            //sinaliza que terminou de escrever, acorda a thread comunicacao e libera mutex
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
            //encerra a thread
            pthread_exit(NULL);
        }
        if(r_pos == 0){ //desativa a restrição de localização
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de localização desativada!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
            pthread_exit(NULL);
        } else {
            //pega a posição atual dada pelo gps
            p_atual.lat1 = g_lat;
            p_atual.long1 = g_long;
        
            //calcula a distancia em km entre as duas posições
            d = calculaDistancia(centro_sm, p_atual);
            printf("d: %f\n", d); //debug
            if(d > 40.0){
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "AVISO:\tVEÍCULO FORA DA ÁREA PERMITIDA!\n");
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            }
        }
        wait_period(&info);
    }
}
//

// (rastreamento) ---- comando que ativa/desativa o rastreador
void switchTracing(){
    pthread_t t1;
    int rc;
    
    pthread_mutex_lock(&mutex);
    if(estado_gps == 1){   
        //desliga o rastreador
        estado_gps = 0; 
    }else{
        //liga o rastreador, cria a thread do GPS
        rc = pthread_create(&t1, NULL, gps, NULL);
        pthread_setaffinity_np(t1, sizeof(s), &s);
        pthread_setschedparam(t1, SCHED_RR, &param);
        estado_gps = 1; // ligado
        if(rc){
            //obtém mutex e escreve no vetor de retorno
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Erro ativando o rastreador!\n");
            estado_gps = 0;
            //sinaliza que uma nova string foi escrita em r_vet (sincronização)
            g_cont++;
            //sinaliza que terminou de escrever, acorda a thread comunicacao e libera mutex 
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }else{
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Rastreador ativado!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }
    }
    pthread_mutex_unlock(&mutex);
}

// (controle) ---- comando que ativa/desativa a restrição de velocidade, cria a thread velocímetro
void speedControl(){
    pthread_t t1;
    int rc;

    pthread_mutex_lock(&mutex);
    if(r_vel == 1){
        //desativa a restrição de velocidade
        r_vel = 0;
    }else{
        //ativa a restrição de velocidade, cria a thread velocímetro
        rc = pthread_create(&t1, NULL, velocimetro, NULL); 
        pthread_setaffinity_np(t1, sizeof(s), &s);
        pthread_setschedparam(t1, SCHED_RR, &param);
        if(rc){
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Erro ativando a restrição de velocidade!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }else{
            pthread_mutex_lock(&ret_mutex);
            r_vel = 1; //ativado
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de velocidade ativada!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }
    }
    pthread_mutex_unlock(&mutex);
}

// (localizacao) ---- comando que ativa/desativa a restrição de localização, cria a thread restriteLocation, que verifica se a posição atual está fora do raio permitido 
void restrictLocation(){
    pthread_t t1;
    int rc;
    
    pthread_mutex_lock(&mutex);
    if(r_pos == 1){  
        //desabilita a restrição de localização
        r_pos = 0;
    }else{
        //habilita a restrição de localização
        rc = pthread_create(&t1, NULL, restricao, NULL);
        pthread_setaffinity_np(t1, sizeof(s), &s);
        pthread_setschedparam(t1, SCHED_RR, &param);
        if(rc){
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Erro ativando a restrição de localização!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }else{
            pthread_mutex_lock(&ret_mutex);
            r_pos = 1; //ligado
            snprintf(r_vet, sizeof(r_vet) - 1, "Restrição de localização ativada!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
        }
    }
    pthread_mutex_unlock(&mutex);
}

// (deslocamento) ------- comando que obtém a distância percorrida desde o início do rastreamento
double getDistance(){
    
    return g_dist; 
}
