#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>

#include "rastreador.h"

#define TOTAL 5

//struct utilizada para passar os parâmetros de inicialização do server através da pthread_create
typedef struct serverParam {
    int argc;
    char **argv;
} serverParam;

pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

struct nodo {
    int newsockfd;
};

struct nodo nodo[5];

//variáveis globais para comunicação
long g_cid;

//thread responsável por enviar as respostas ao cliente
void *comunicacao(void *arg){
    // estrutura para fazer a thread ser periódica
	struct periodic_info info;
    char msg[256];
    int rc, cont = g_cont;

    bzero(r_vet, sizeof(r_vet));
    bzero(msg, sizeof(msg));

    while(1){
         pthread_mutex_lock(&ret_mutex);
         while(escrevendo_rvet == 0){
             pthread_cond_wait(&ret_cond, &ret_mutex);
         }
         //teste
         rc = write(nodo[g_cid].newsockfd, r_vet, 85);
         bzero(r_vet, sizeof(r_vet));
         if(rc <= 0){
             printf("Thread Comunicação - Erro escrevendo no socket!\n");
         }
         // fim teste
         /*if((g_cont - cont) == 1){
             rc = write(nodo[g_cid].newsockfd, r_vet, 256);
             bzero(r_vet, sizeof(r_vet));
             if(rc <= 0){
                 printf("Thread Comunicação - Erro escrevendo no socket!\n");
             }
         } 
         else if((g_cont - cont) > 1){
             printf("Strings de retorno foram perdidas!\n"); 
         }*/
         escrevendo_rvet = 0;
         //cont = g_cont;
         /*if(strcmp(msg, buffer_ret) != 0){
             rc = write(nodo[g_cid].newsockfd, buffer_ret, 256);
             if(rc <= 0){
                 printf("Thread Comunicação - Erro escrevendo no socket!\n");
             }
             strcpy(msg, buffer_ret);
         }*/
         //pthread_cond_signal(&ret_cond);
         pthread_mutex_unlock(&ret_mutex);
    }
}

void *cliente(void *arg) {
    pthread_t t1;
    long cid = (long)arg;
    int i, n, rc;
    char buffer[256];
    while (1) {
        bzero(buffer,sizeof(buffer));
        n = read(nodo[cid].newsockfd,buffer,85);
        printf("Recebeu: %s - %lu\n", buffer, strlen(buffer));
        if (n <= 0) {
            printf("Erro lendo do socket id %lu!\n", cid);
            close(nodo[cid].newsockfd);
            nodo[cid].newsockfd = -1;

            pthread_exit(NULL);
        }
        // MUTEX LOCK - GERAL
        pthread_mutex_lock(&m);
        g_cid = cid;
        if(strcmp(buffer, "rastreamento\n") == 0){
            //função que ativa/desativa o rastreamento
            switchTracing();       
        }
        else if(strcmp(buffer, "controle\n") == 0){
            if(estado_gps == 0){
                //obtém mutex e escreve no vetor de retorno
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Rastreador desativado. Controle de velocidade indisponível!\n");
                //sinaliza no contador global que há uma nova string para ser printada (sincronização)
                g_cont++;
                //sinaliza que terminou de escrever, acorda a thread comunicacao e libera mutex
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            } else {
                //função que ativa/desativa o controle de velocidade
                speedControl();
            }
        }
        else if(strcmp(buffer, "localizacao\n") == 0){
            if(estado_gps == 0){
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Rastreador desativado. Restricao de localização indisponível!\n");
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            } else {
                //função que ativa/desativa a restrição de localização
                restrictLocation();
            }
        }
        else if(strcmp(buffer, "deslocamento\n") == 0){
            if(estado_gps == 0){
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Rastreador desativado. Distância percorrida indisponível!\n");
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            } else {
                //função que obtém a distância percorrida desde o início do rastreamento
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Distância percorrida:\t%f\n", getDistance());
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            }
        }
        else if(strcmp(buffer, "velocidade\n") == 0){
            if(estado_gps == 0){
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Rastreador desativado. Velocidade média atual indisponível\n");
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            } else {
                //função que obtém a velocidade média atual
                pthread_mutex_lock(&ret_mutex);
                snprintf(r_vet, sizeof(r_vet) - 1, "Velocidade media atual:\t%f\n", getSpeed());
                g_cont++;
                escrevendo_rvet = 1;
                pthread_cond_signal(&ret_cond);
                pthread_mutex_unlock(&ret_mutex);
            }
        } else {
            pthread_mutex_lock(&ret_mutex);
            snprintf(r_vet, sizeof(r_vet) - 1, "Comando indisponível!\n");
            g_cont++;
            escrevendo_rvet = 1;
            pthread_cond_signal(&ret_cond);
            pthread_mutex_unlock(&ret_mutex);
            for (i = 0;i < TOTAL; i++) {
                if ((i != cid) && (nodo[i].newsockfd != -1)) {
                    n = write(nodo[i].newsockfd,buffer,80);
                    if (n <= 0) {
                        printf("Erro escrevendo no socket id %i!\n", i);
//                      close(nodo[i].newsockfd);
//                      nodo[i].newsockfd = -1;
                    }
                }
            }
        }
        pthread_mutex_unlock(&m);
        // MUTEX UNLOCK - GERAL
    }
}

void *server(void *arg) {
    //teste
    struct serverParam *servidor1 = (serverParam*)arg;
    int argc = servidor1->argc;
    char **argv = servidor1->argv;
    //

    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;
    int sockfd, portno;
    pthread_t t, t1;
    long i;

    if (argc < 2) {
        printf("Erro, porta nao definida!\n");
        printf("./SOFTWARE PORTA");
        exit(1);
    }
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        printf("Erro abrindo o socket!\n");
        exit(1);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) {
        printf("Erro fazendo bind!\n");
        exit(1);
    }
    listen(sockfd,5);

    for (i = 0; i < TOTAL; i++) {
      nodo[i].newsockfd = -1;
    }
    while (1) {
        for (i = 0; i < TOTAL; i++) {
          if (nodo[i].newsockfd == -1) break;
        }
        nodo[i].newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr,&clilen);
        // MUTEX LOCK - GERAL
        pthread_mutex_lock(&m);
        if (nodo[i].newsockfd < 0) {
            printf("Erro no accept!\n");
            exit(1);
        }
        pthread_create(&t, NULL, cliente, (void *)i);
        pthread_setaffinity_np(t, sizeof(s), &s);
        pthread_setschedparam(t, SCHED_RR, &param);
        pthread_create(&t1, NULL, comunicacao, NULL);
        pthread_setaffinity_np(t1, sizeof(s), &s);
        pthread_setschedparam(t1, SCHED_RR, &param);

        pthread_mutex_unlock(&m);
        // MUTEX UNLOCK - GERAL
    }
    //    close(sockfd);
    return 0; 
}


